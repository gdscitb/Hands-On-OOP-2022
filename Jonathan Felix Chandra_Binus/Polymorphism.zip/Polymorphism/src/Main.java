import java.util.ArrayList;
import java.util.Scanner;



public class Main {
    
	Scanner scan = new Scanner(System.in);
	ArrayList<Animal> animalList = new ArrayList<Animal>();
	
	public Main() {
//		Menu
//		1.Create Animal (Dog, Cat, Snake, Cow)
//		2.Hear Animal Sound
//		3.Introduced Animal
		
		int choice = 0;
		
		do {
			System.out.println("1.Create Animal");
			System.out.println("2.Hear Animal Sound");
			System.out.println("3.Introduced animal");
			System.out.println("4.Print Animal");
			System.out.println("5.Exit");
			System.out.print(">>");
			choice = scan.nextInt(); scan.nextLine();
		    if(choice == 1) {
		    	createAnimal();
		     }else if(choice == 2) {
		    	animalSound();
		     }else if(choice == 3) {
		    	 introduceAnimal();
		     }else if(choice == 4) {
		    	 printAnimal();
		     }
		    
		} while (choice != 5);
		
		
		
	}
	private void introduceAnimal() {
		printAnimal();
//		0 - index terakhir dri animelist
		System.out.print("Choose animal index:");
		int choice = scan.nextInt(); scan.nextLine();
		
		Animal animal = animalList.get(choice);
		animal.sound(" Hello");
	}
	public void animalSound() {
		printAnimal();
//		0 - index terakhir dri animelist
		System.out.print("Choose animal index:");
		int choice = scan.nextInt(); scan.nextLine();
		
		Animal animal = animalList.get(choice);
		animal.sound();
	}
	
	public void printAnimal(){
//		for(Animal animal : animalList) {
//			System.out.println("Name:" + animal.getName());
//		    System.out.println("Age:" + animal.getAge());
//		    System.out.println("Weight" + animal.getWeight());
//		    System.out.println();
//		}
		
		for(int i = 0; i<animalList.size(); i++) {
			Animal animal = animalList.get(i);
			System.out.println("Name:" + animal.getName());
		    System.out.println("Age:" + animal.getAge());
		    System.out.println("Weight" + animal.getWeight());
		    System.out.println();
		}
	}
	
	public void createAnimal() {
		String type, name;
		int age;
		double weight;
		//Input Type [Dog | Cat | Snake | Cow]
		System.out.println("Input Type[Dog | Cat | Snake | Cow]:");
		type = scan.nextLine();
		//Input Name
		System.out.println("Input Name:");
		name = scan.nextLine();
		//Input Age
		System.out.println("Input age:");
		age = scan.nextInt();
		//Input weight
		System.out.println("Input weight:");
		weight = scan.nextDouble();
	
		if(type.equals("Dog")) {
			//add -> tambahin object ke arraylist
			animalList.add(new Dog(name, age, weight));
		} else if (type.equals("Cat")){
			animalList.add(new Cat(name, age, weight));
		}else if (type.equals("Snake")){
			animalList.add(new Snake(name, age, weight));
		}else if (type.equals("Cow")){
			animalList.add(new Cow(name, age, weight));
		}
	}
	
	
	
	public static void main(String[] args) {
		new Main();

	}

}
