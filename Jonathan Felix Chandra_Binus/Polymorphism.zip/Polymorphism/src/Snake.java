
public class Snake extends Animal {

	public Snake(String name, int age, double weight) {
		super(name, age, weight);
		// TODO Auto-generated constructor stub
	}

	public void sound() {
		System.out.println("Shh shh");
	}
}
