
public class Dog extends Animal {

	public Dog(String name, int age, double weight) {
		super(name, age, weight);
		
	
	}

	
	public void sound() {
		System.out.println("Woof woof");
	}
}
