
public class Cow extends Animal {

	public Cow(String name, int age, double weight) {
		super(name, age, weight);
		// TODO Auto-generated constructor stub
	}

	public void sound() {
		System.out.println("Mooo");
	}
}
