
public class Cat extends Animal {

	public Cat(String name, int age, double weight) {
		super(name, age, weight);
		// TODO Auto-generated constructor stub
	}

	public void sound() {
		System.out.println("Meow meow");
	}
}
