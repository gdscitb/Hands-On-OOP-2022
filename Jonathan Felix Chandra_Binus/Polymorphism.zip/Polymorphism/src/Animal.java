
public abstract class  Animal {
   
	//attribute > name, age, weight
	protected String name;
	protected int age = 0;
	protected double weight;
	
	//Constructor
	
	public Animal(String name, int age, double weight) {
		super();
		this.name = name;
		this.age = age;
		this.weight = weight;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public double getWeight() {
		return weight;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}
	
	//sound
	public abstract void sound();
	
	public void sound(String str) {
		System.out.println(str + "my name is" + this.name);
	}
	
	
	
}
